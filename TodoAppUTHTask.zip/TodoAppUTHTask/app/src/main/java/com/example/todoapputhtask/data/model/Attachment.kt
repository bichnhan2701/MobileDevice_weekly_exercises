package com.example.todoapputhtask.data.model

data class Attachment (
    val id: Int,
    val fileName: String,
    val fileUrl: String
)