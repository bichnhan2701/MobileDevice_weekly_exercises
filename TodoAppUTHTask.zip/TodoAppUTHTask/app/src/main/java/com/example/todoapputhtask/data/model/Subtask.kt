package com.example.todoapputhtask.data.model

data class Subtask (
    val id: Int,
    val title: String,
    val isCompleted: Boolean
)