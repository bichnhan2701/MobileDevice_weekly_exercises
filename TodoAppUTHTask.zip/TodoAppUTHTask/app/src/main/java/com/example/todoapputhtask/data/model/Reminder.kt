package com.example.todoapputhtask.data.model

data class Reminder (
    val id: Int,
    val time: String,
    val type: String
)